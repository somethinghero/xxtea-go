// xxteatest.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <string>
#include <fstream>
#include "xxtea\xxtea.h"
#include "xxtea\xxtea_ext.h"

#define SAFE_FREE(ptr) if(ptr != nullptr){free(ptr);ptr = nullptr;}

unsigned char* read_data(const char* filename, xxtea_long* readsize);
void write_data(const char* filename, char* data, int size);

int _tmain(int argc, _TCHAR* argv[])
{
	xxtea_ext_init();
	char filename1[] = "1.txt";
	char filename2[] = "2.txt";
	char filename3[] = "3.txt";
	char filename4[] = "4.txt";

	xxtea_long len1 = 0;
	xxtea_long len2 = 0;
	xxtea_long len3 = 0;
	xxtea_long len4 = 0;

	unsigned char *data1 = read_data(filename1, &len1);
	unsigned char *data2 = read_data(filename2, &len2);
	unsigned char *data3 = read_data(filename3, &len3);
	unsigned char *data4 = read_data(filename4, &len4);

	unsigned char key[] = "1231232324";

	xxtea_long retlen1 = 0;
	xxtea_long retlen2 = 0;
	xxtea_long retlen3 = 0;
	xxtea_long retlen4 = 0;
	unsigned char *endata1 = xxtea_ext_encrypt(data1, len1, key, sizeof(key), &retlen1);
	unsigned char *endata2 = xxtea_ext_encrypt(data2, len2, key, sizeof(key), &retlen2);
	unsigned char *endata3 = xxtea_ext_encrypt(data3, len3, key, sizeof(key), &retlen3);
	unsigned char *endata4 = xxtea_ext_encrypt(data4, len4, key, sizeof(key), &retlen4);

	write_data("1.data", (char*)endata1, retlen1);
	write_data("2.data", (char*)endata2, retlen2);
	write_data("3.data", (char*)endata3, retlen3);
	write_data("4.data", (char*)endata4, retlen4);

	xxtea_long delen1 = 0;
	xxtea_long delen2 = 0;
	xxtea_long delen3 = 0;
	xxtea_long delen4 = 0;
	unsigned char *dedata1 = xxtea_ext_decrypt(endata1, retlen1, key, sizeof(key), &delen1);
	unsigned char *dedata2 = xxtea_ext_decrypt(endata2, retlen2, key, sizeof(key), &delen2);
	unsigned char *dedata3 = xxtea_ext_decrypt(endata3, retlen3, key, sizeof(key), &delen3);
	unsigned char *dedata4 = xxtea_ext_decrypt(endata4, retlen4, key, sizeof(key), &delen4);

	_ASSERT(strncmp((char*)data1, (char*)dedata1, len1) == 0);
	_ASSERT(strncmp((char*)data2, (char*)dedata2, len2) == 0);
	_ASSERT(strncmp((char*)data3, (char*)dedata3, len3) == 0);
	_ASSERT(strncmp((char*)data4, (char*)dedata4, len4) == 0);

	xxtea_long size1 = 0;
	xxtea_long size2 = 0;
	unsigned char * random_data1 = xxtea_ext_encrypt(data1, len1, key, sizeof(key), &size1);
	unsigned char * random_data2 = xxtea_ext_encrypt(data1, len1, key, sizeof(key), &size2);

	xxtea_long realsize1 = 0;
	xxtea_long realsize2 = 0;
	unsigned char *real_data1 = xxtea_ext_decrypt(random_data1, size1, key, sizeof(key), &realsize1);
	unsigned char *real_data2 = xxtea_ext_decrypt(random_data2, size2, key, sizeof(key), &realsize2);

	_ASSERT(strncmp((char*)real_data1, (char*)data1, len1) == 0);
	_ASSERT(strncmp((char*)real_data2, (char*)data1, len1) == 0);

	SAFE_FREE(random_data1);
	SAFE_FREE(random_data2);
	SAFE_FREE(real_data1);
	SAFE_FREE(real_data2);

	SAFE_FREE(endata1);
	SAFE_FREE(endata2);
	SAFE_FREE(endata3);
	SAFE_FREE(endata4);
	SAFE_FREE(dedata1);
	SAFE_FREE(dedata2);
	SAFE_FREE(dedata3);
	SAFE_FREE(dedata4);
	SAFE_FREE(data1);
	SAFE_FREE(data2);
	SAFE_FREE(data3);
	SAFE_FREE(data4);
	return 0;
}

unsigned char* read_data(const char* filename, xxtea_long* readsize)
{
	unsigned char *ret = nullptr;
	std::ifstream in;
	in.open(filename, std::ios::in | std::ios::binary);
	in.seekg(0, std::ios::end);
	auto len = (int)in.tellg();
	(*readsize) = len;
	ret = (unsigned char*)malloc(len);
	in.seekg(std::ios::beg);
	in.read((char*)ret, len);
	in.close();
	return ret;
}

void write_data(const char* filename, char* data, int size)
{
	std::ofstream out1;
	out1.open(filename, std::ios::out | std::ios::binary);
	out1.seekp(std::ios::beg);
	out1.write(data, size);
	out1.close();
}