#include "xxtea_ext.h"
#include <memory.h>
#include <stdlib.h>
#include <time.h>

void xxtea_ext_init()
{
	srand((unsigned int)time(NULL));
}

unsigned char *fix_data(unsigned char *data, xxtea_long data_len, xxtea_long* fixed_len)
{
	unsigned char fix_byte_count = 4 - (unsigned char)((data_len + 1) % 4);

	unsigned char *fixeddata = (unsigned char*)malloc(data_len + fix_byte_count + 1);

	*fixed_len = data_len + fix_byte_count + 1;
	//write one byte as fix byte count
	memcpy(fixeddata, &fix_byte_count, 1);

	//write random fix byte
	if (fix_byte_count > 0)
	{
		unsigned char rvalue = 0;
		for (unsigned char i = 0; i < fix_byte_count; i++)
		{
			rvalue = (unsigned char)rand();
			memcpy(fixeddata + i + 1, &rvalue, 1);
		}
	}

	//write origin data
	memcpy(fixeddata + fix_byte_count + 1, data, data_len);

	return fixeddata;
}

unsigned char *unfixed_data(unsigned char *data, xxtea_long data_len, xxtea_long* real_len)
{
	//read one byte as fixed count
	unsigned char fix_byte_count = data[0];
	*real_len = data_len - fix_byte_count - 1;
	return data + fix_byte_count + 1;
}

unsigned char *xxtea_ext_encrypt(unsigned char *data, xxtea_long data_len, unsigned char *key, xxtea_long key_len, xxtea_long *ret_length)
{
	xxtea_long fixed_len = 0;
	unsigned char* fixeddata = fix_data(data, data_len, &fixed_len);
	unsigned char* ret = xxtea_encrypt(fixeddata, fixed_len, key, key_len, ret_length);
	free(fixeddata);
	fixeddata = nullptr;
	return ret;
}

unsigned char *xxtea_ext_decrypt(unsigned char *data, xxtea_long data_len, unsigned char *key, xxtea_long key_len, xxtea_long *ret_length)
{
	xxtea_long de_len = 0;
	unsigned char *de_data = xxtea_decrypt(data, data_len, key, key_len, &de_len);

	xxtea_long real_len = 0;
	unsigned char *realdata = unfixed_data(de_data, de_len, &real_len);

	unsigned char *ret = (unsigned char*)malloc(real_len);
	memcpy(ret, realdata, real_len);

	*ret_length = real_len;
	free(de_data);

	return ret;
}