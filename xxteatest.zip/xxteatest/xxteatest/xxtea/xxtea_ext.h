#ifndef XXTEA_EXT_H
#define XXTEA_EXT_H

#include "xxtea.h"

//add random fix byte to ensure same input and diff output per encrypt
unsigned char *xxtea_ext_encrypt(unsigned char *data, xxtea_long data_len, unsigned char *key, xxtea_long key_len, xxtea_long *ret_length);
unsigned char *xxtea_ext_decrypt(unsigned char *data, xxtea_long data_len, unsigned char *key, xxtea_long key_len, xxtea_long *ret_length);

void xxtea_ext_init();

#endif